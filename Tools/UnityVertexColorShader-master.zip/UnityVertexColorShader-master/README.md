# UnityVertexColorShader
Modifying the versions uploaded here - https://forum.unity3d.com/threads/standard-shader-with-vertex-colors.316529/ and added a downloadable unity package to it.
